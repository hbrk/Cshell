#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include<sys/syscall.h>
#include <sys/stat.h>
#include <sys/types.h>
#include<string.h>
//readme.md
int main(int argc,char* argv[])
{
	if(argc<2 || argc>2)
	{
		perror("Sufficient arguments are not given and the format of giving arguments is ./a.out <path_to_inputfile>");
		exit(1);
	}
	int fd1,fd2;
	//const char* file;
	//file=argv[1];
	fd1=open(argv[1],O_RDONLY);
        if(fd1<0)
        {
                perror("File doesn't exist");
                exit(1);
       	}

	char directory[50]="Assignment";
	mkdir(directory,0700);	
//	mkdir("Assignment",0700);
	char *filepath = malloc(strlen(directory) + strlen(argv[1]) + 2);
	filepath = strcpy(filepath, directory);
	filepath = strcat(filepath, "/");
	filepath = strcat(filepath,argv[1]);
	int  filelen=lseek(fd1,-1,SEEK_END);
	int  filelen1=filelen;
	if(filelen<0)
	{
		perror("Error in reading");
		exit(1);
	}
	fd2 = open(filepath, O_WRONLY | O_CREAT, 0600);
//	fd2 = open("Assignment/b.txt", O_WRONLY | O_CREAT, 0600);

	if(fd2<0)
	{
		perror("File creation is not possible");
		exit(1);
	}
	lseek(fd1,-1,SEEK_END);
	lseek(fd2,0,SEEK_SET);
	int n=0;
	float p;
	int s=1;
	while(s)
	{
		if(filelen>=1000000)
		{
			char *c1=(char *) calloc(1000000,sizeof(char));
			char *c2=(char *) calloc(1000000,sizeof(char));
			fd1=lseek(fd1,-1000000,SEEK_CUR);
			read(fd1,c1,1000000);
			fd1=lseek(fd1,-1000000,SEEK_CUR);
			while(filelen>=0)
			{
				n++;
				int i=0;
				c2[i++]=c1[filelen-1];
			}
			char buffer[50];
			write(fd2,c2,1000000);
			filelen=filelen-1000000;
			p=((float)(n)/(float)(filelen1))*100;
			sprintf(buffer,"%.2f%%",p);
			write(1,"\r",strlen("\r"));
			write(1,buffer,strlen(buffer));
			fflush(stdout);
		}
		else
		{
			char *c1=(char *) calloc(filelen,sizeof(char));
			char *c2=(char *) calloc(filelen+1,sizeof(char));
			lseek(fd1,0,SEEK_SET);
			read(fd1,c1,filelen);
			while(filelen>0)
			{
				n++;
				int k=0;
				c2[k++]=c1[filelen-1];
			}
			char buffer[50];
			write(fd2,c2,filelen);
			p=((float)(n)/(float)(filelen1))*100;
			sprintf(buffer,"%.2f%%",p);
			write(1,"\r",strlen("\r"));
			write(1,buffer,strlen(buffer));
			fflush(stdout);
			break;
		}
	}
	close(fd1);
	close(fd2);
}
