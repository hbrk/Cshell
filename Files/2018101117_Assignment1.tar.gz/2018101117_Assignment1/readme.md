Part 1:
------
#For compilation: gcc Q1.c
#For execution: ./a.out <path_to_inputfile>

#Do the compilation in 2018101117_Assignment1 folder
#If the given number of input arguments are not sufficient i.e argc must be 2(here),corresponding error message will be displayed.
#If the given input file doesn't exist,corresponding error message will be displayed.
#The path of the created file is Assignment/inputfilename
#Take relative path of the input file while execution
 
________________________________________________________________________________

Part 2:
------
#For compilation: gcc Q2.c
#For execution: ./a.out oldfilename newfilename directoryname

#If the given number of input arguments are not sufficient i.e. argc must be 4(here),corresponding error message will be displayed.
