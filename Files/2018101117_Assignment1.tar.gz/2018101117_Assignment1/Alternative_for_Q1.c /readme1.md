#This is for re3.c
For compilation:gcc re3.c
For execution:./a.out inputfilename outputfilename

The path of created file is Assignment/outputfilename
Take realtive file path for execution

