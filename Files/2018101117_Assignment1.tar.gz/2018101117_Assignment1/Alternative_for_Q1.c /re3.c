#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include<sys/syscall.h>
#include <sys/stat.h>
#include <sys/types.h>
#include<string.h>

long int  main(long int argc, char * argv[]) 
{
	long int fd1, fd2;  
	char c;       
	long int offset,size;    
	char directory[50]="Assignment";
        mkdir(directory,0700);
        char *filepath = malloc(strlen(directory) + strlen(argv[2]) + 2);
        filepath = strcpy(filepath, directory);
        filepath = strcat(filepath, "/");
	filepath = strcat(filepath,argv[2]);   

	fd1 = open(argv[1], O_RDONLY);
	if (argc < 2) return 0;
	size = lseek(fd1,0,SEEK_END);
	printf("%ld\n",size);     
	fd2 = open(filepath, O_WRONLY | O_CREAT | O_TRUNC, 0600);
	offset = lseek(fd1, -2, SEEK_END);   
	while (offset > -1) 
	{       
		read(fd1, &c, 1);  
		write(fd2, &c, 1);
		lseek(fd1, -2, SEEK_CUR);
		offset--; 
	}
	close(fd1); 
	close(fd2);
}
