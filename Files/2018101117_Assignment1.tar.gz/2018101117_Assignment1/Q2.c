#include <stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/syscall.h>
#include <sys/stat.h>
#include<fcntl.h>
#include<math.h>
//readme.md
int stat(const char *path, struct stat *buf);

long int main(long int argc, char* argv[])
{
	//error handling
	if(argc<4 || argc>4)
	{
		perror("Sufficient arguments are not given and the format of giving arguments is ./a.out oldfilename newfilename directory");
		exit(1);
	}

	const char* folder;
	folder = argv[3];
	struct stat sb;
	const char msg1[] = "Directory is created:Yes\n";
	const char msg2[] = "Directory is created:NO\n";
	const char msg3[] = "Whether file contents are reversed in newfile:Yes\n";
	const char msg4[] = "Whether file contents are reversed in newfile:No\n"; 
	const char msg5[] = "\n";

	//Checking whether the directory is existed or not

	if (stat(folder, &sb) == 0 && S_ISDIR(sb.st_mode)) 
	{
		syscall(SYS_write, 1, msg1, sizeof(msg1));
	} 
	else 
	{
		syscall(SYS_write,1,msg2,sizeof(msg2));

	}

	//Checking Whether the file contents are reversed in newfile or not

	long int oldfile = open(argv[1], O_RDONLY | __O_LARGEFILE);
	long int newfile = open(argv[2], O_RDONLY | __O_LARGEFILE);
	if (oldfile < 0 || newfile < 0) //errorhandling
	{
		perror("Files are not existed\n");
		exit(1);
	}

	else
	{
		long int old_filelen = lseek(oldfile, 0, SEEK_END);
		long int new_filelen = lseek(newfile, 0, SEEK_END);
		if (old_filelen != new_filelen)
			syscall(SYS_write,1,msg4,sizeof(msg4));

		else
		{
			long int flag = 0;
			lseek(oldfile, 0, SEEK_SET);
			lseek(newfile, -2, SEEK_END);
			for(long int i=0;i<old_filelen-1;i++)
			{
				char newchar, oldchar;
				read(oldfile, &oldchar, 1);
				read(newfile, &newchar, 1);
				lseek(newfile, -2, SEEK_CUR);
				if (oldchar != newchar)
				{
					flag = 1;
					syscall(SYS_write,1,msg4,sizeof(msg4));
					break;
				}
			}
			if (flag == 0)
				syscall(SYS_write,1,msg3,sizeof(msg3));

		}
	}

	syscall(SYS_write,1,msg5,sizeof(msg5));

	//Checking the permissions for oldfile,newfile and the directory

	struct stat stats1;
	struct stat stats2;
	long int fileMode,file1Mode,dirMode;

	if(stat(argv[1],&stats1) < 0)
		return 1;
	if(stat(argv[2],&stats2) < 0)
		return 1;
	if(stat(argv[3],&sb)<0)
		return 1;

	const char msg30[] = "User has read permission on newfile:Yes\n";
	const char msg31[] = "User has write permission on newfile:Yes\n";
	const char msg32[] = "User has execute permission on newfile:Yes\n";

	const char msg300[] = "User has read permissions on newfile:No\n";
	const char msg311[] = "User has write permission on newfile:No\n";
	const char msg312[] = "User has execute permission on newfile:No\n";

	const char msg40[] = "Group has read permissions on newfile:Yes\n";
	const char msg41[] = "Group has write permission on newfile:Yes\n";
	const char msg42[] = "Group has execute permission on newfile:Yes\n";

	const char msg400[] = "Group has read permissions on newfile:No\n";
	const char msg411[] = "Group has write permission on newfile:No\n";
	const char msg412[] = "Group has execute permission on newfile:No\n";

	const char msg50[] = "Others has  read permissions on newfile:Yes\n";
	const char msg51[] = "Others has write permission on newfile:Yes\n";
	const char msg52[] = "Others has execute permission on newfile:Yes\n";

	const char msg500[] = "Others has read permissions on newfile:No\n";
	const char msg511[] = "Others has write permission on newfile:No\n";
	const char msg512[] = "Others has execute permission on newfile:No\n";

	const char msg60[] = "User has read permissions on oldfile:Yes\n";
	const char msg61[] = "User has write permission on oldfile:Yes\n";
	const char msg62[] = "User has execute permission on oldfile:Yes\n";

	const char msg600[] = "User has read permissions on oldfile:No\n";
	const char msg611[] = "User has write permission on oldfile:No\n";
	const char msg612[] = "User has execute permission on oldfile:No\n";

	const char msg70[] = "Group has read permissions on oldfile:Yes\n";
	const char msg71[] = "Group has write permission on oldfile:Yes\n";
	const char msg72[] = "Group has execute permission on oldfile:Yes\n";

	const char msg700[] = "Group has read permissions on oldfile:No\n";
	const char msg711[] = "Group has write permission on oldfile:No\n";
	const char msg712[] = "Group has execute permission on oldfile:No\n";

	const char msg80[] = "Others has  read permissions on oldfile:Yes\n";
	const char msg81[] = "Others has write permission on oldfile:Yes\n";
	const char msg82[] = "Others has execute permission on oldfile:Yes\n";

	const char msg800[] = "Others has read permissions on oldfile:No\n";
	const char msg811[] = "Others has write permission on oldfile:No\n";
	const char msg812[] = "Others has execute permission on oldfile:No\n";

	const char msg90[] = "User has read permissions on directory:Yes\n";
	const char msg91[] = "User has write permission on directory:Yes\n";
	const char msg92[] = "User has execute permission on directory:Yes\n";

	const char msg900[] = "User has read permissions on directory:No\n";
	const char msg911[] = "User has write permission on directory:No\n";
	const char msg912[] = "User has execute permission on directory:No\n";

	const char msg10[] = "Group has read permissions on directory:Yes\n";
	const char msg11[] = "Group has write permission on directory:Yes\n";
	const char msg12[] = "Group has execute permission on directory:Yes\n";

	const char msg100[] = "Group has read permissions on directory:No\n";
	const char msg111[] = "Group has write permission on directory:No\n";
	const char msg112[] = "Group has execute permission on directory:No\n";

	const char msg20[] = "Others has  read permissions on directory:Yes\n";
	const char msg21[] = "Others has write permission on directory:Yes\n";
	const char msg22[] = "Others has execute permission on directory:Yes\n";

	const char msg200[] = "Others has read permissions on directory:No\n";
	const char msg211[] = "Others has write permission on directory:No\n";
	const char msg212[] = "Others has execute permission on directory:No\n";

	fileMode = stats2.st_mode;
	file1Mode = stats1.st_mode;
	dirMode = sb.st_mode;

	//check owner permissions for an old file
	if ((file1Mode & S_IRUSR) && (file1Mode & S_IREAD))
		syscall(SYS_write, 1, msg60, sizeof(msg60));
	else
		syscall(SYS_write, 1, msg600, sizeof(msg600));
	if ((file1Mode & S_IWUSR) && (file1Mode & S_IWRITE)) 
		syscall(SYS_write, 1, msg61, sizeof(msg31));
	else
		syscall(SYS_write, 1, msg611, sizeof(msg611));
	if ((file1Mode & S_IXUSR) && (file1Mode & S_IEXEC))
		syscall(SYS_write, 1, msg62, sizeof(msg62));
	else
		syscall(SYS_write, 1, msg612, sizeof(msg612));

	syscall(SYS_write, 1, msg5, sizeof(msg5));

	// Check group permissions for an old file
	if ((file1Mode & S_IRGRP) && (file1Mode & S_IREAD))
		syscall(SYS_write, 1, msg70, sizeof(msg70));
	else
		syscall(SYS_write, 1, msg700, sizeof(msg700));
	if ((file1Mode & S_IWGRP) && (file1Mode & S_IWRITE))
		syscall(SYS_write, 1, msg71, sizeof(msg71));
	else
		syscall(SYS_write, 1, msg711, sizeof(msg711));
	if ((file1Mode & S_IXGRP) && (file1Mode & S_IEXEC))
		syscall(SYS_write, 1, msg72, sizeof(msg72));
	else
		syscall(SYS_write, 1, msg712, sizeof(msg712));

	syscall(SYS_write, 1, msg5, sizeof(msg5));

	// check other user permissions for an old file
	if ((file1Mode & S_IROTH) && (file1Mode & S_IREAD))
		syscall(SYS_write, 1, msg80, sizeof(msg80));
	else
		syscall(SYS_write, 1, msg800, sizeof(msg800));
	if ((file1Mode & S_IWOTH) && (file1Mode & S_IWRITE))
		syscall(SYS_write, 1, msg81, sizeof(msg81));
	else
		syscall(SYS_write, 1, msg811, sizeof(msg811));
	if ((file1Mode & S_IXOTH) && (file1Mode & S_IEXEC))
		syscall(SYS_write, 1, msg82, sizeof(msg82));
	else
		syscall(SYS_write, 1, msg812, sizeof(msg812));

	syscall(SYS_write, 1, msg5, sizeof(msg5));


	//Check user Permissions for the new file
	if ((fileMode & S_IRUSR) && (fileMode & S_IREAD))
		syscall(SYS_write, 1, msg30, sizeof(msg30));
	else
		syscall(SYS_write, 1, msg300, sizeof(msg300));
	if ((fileMode & S_IWUSR) && (fileMode & S_IWRITE))
		syscall(SYS_write, 1, msg31, sizeof(msg31));
	else
		syscall(SYS_write, 1, msg311, sizeof(msg311));
	if ((fileMode & S_IXUSR) && (fileMode & S_IEXEC))
		syscall(SYS_write, 1, msg32, sizeof(msg32));
	else
		syscall(SYS_write, 1, msg312, sizeof(msg312));

	syscall(SYS_write, 1, msg5, sizeof(msg5));


	// Check group permissions for the new file
	if ((fileMode & S_IRGRP) && (fileMode & S_IREAD))
		syscall(SYS_write, 1, msg40, sizeof(msg40));
	else
		syscall(SYS_write, 1, msg400, sizeof(msg400));
	if ((fileMode & S_IWGRP) && (fileMode & S_IWRITE))
		syscall(SYS_write, 1, msg41, sizeof(msg41));
	else
		syscall(SYS_write, 1, msg411, sizeof(msg411));
	if ((fileMode & S_IXGRP) && (fileMode & S_IEXEC))
		syscall(SYS_write, 1, msg42, sizeof(msg42));
	else
		syscall(SYS_write, 1, msg412, sizeof(msg412));

	syscall(SYS_write, 1, msg5, sizeof(msg5));


	// check other user permissions for the new file
	if ((fileMode & S_IROTH) && (fileMode & S_IREAD))
		syscall(SYS_write, 1, msg50, sizeof(msg50));
	else
		syscall(SYS_write, 1, msg500, sizeof(msg500));
	if ((fileMode & S_IWOTH) && (fileMode & S_IWRITE))
		syscall(SYS_write, 1, msg51, sizeof(msg51));
	else
		syscall(SYS_write, 1, msg511, sizeof(msg511));
	if ((fileMode & S_IXOTH) && (fileMode & S_IEXEC))
		syscall(SYS_write, 1, msg52, sizeof(msg52));
	else
		syscall(SYS_write, 1, msg512, sizeof(msg512));

	syscall(SYS_write, 1, msg5, sizeof(msg5));


	//Check owner permissions for the directory
	if ((dirMode & S_IRUSR) && (dirMode & S_IREAD))
		syscall(SYS_write, 1, msg90, sizeof(msg90));
	else
		syscall(SYS_write, 1, msg900, sizeof(msg900));
	if ((dirMode & S_IWUSR) && (dirMode & S_IWRITE))
		syscall(SYS_write, 1, msg91, sizeof(msg91));
	else
		syscall(SYS_write, 1, msg911, sizeof(msg911));
	if ((dirMode & S_IXUSR) && (dirMode & S_IEXEC))
		syscall(SYS_write, 1, msg92, sizeof(msg92));
	else
		syscall(SYS_write, 1, msg912, sizeof(msg912));
	syscall(SYS_write, 1, msg5, sizeof(msg5));

	// Check group permissions for the directory
	if ((dirMode & S_IRGRP) && (dirMode & S_IREAD))
		syscall(SYS_write, 1, msg10, sizeof(msg10));
	else
		syscall(SYS_write, 1, msg100, sizeof(msg100));
	if ((dirMode & S_IWGRP) && (dirMode & S_IWRITE))
		syscall(SYS_write, 1, msg11, sizeof(msg11));
	else
		syscall(SYS_write, 1, msg111, sizeof(msg111));
	if ((dirMode & S_IXGRP) && (dirMode & S_IEXEC))
		syscall(SYS_write, 1, msg12, sizeof(msg12));
	else
		syscall(SYS_write, 1, msg112, sizeof(msg112));

	syscall(SYS_write, 1, msg5, sizeof(msg5));

	// check other user permissions for the directory
	if ((dirMode & S_IROTH) && (dirMode & S_IREAD))
		syscall(SYS_write, 1, msg20, sizeof(msg20));
	else
		syscall(SYS_write, 1, msg200, sizeof(msg200));
	if ((dirMode & S_IWOTH) && (dirMode & S_IWRITE))
		syscall(SYS_write, 1, msg21, sizeof(msg21));
	else
		syscall(SYS_write, 1, msg211, sizeof(msg211));
	if ((dirMode & S_IXOTH) && (dirMode & S_IEXEC))
		syscall(SYS_write, 1, msg22, sizeof(msg22));
	else
		syscall(SYS_write, 1, msg212, sizeof(msg212));
	close(oldfile);
	close(newfile);
}
